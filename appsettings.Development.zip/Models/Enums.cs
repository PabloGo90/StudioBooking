﻿namespace TattooStudioBooking;

public class Enums
{
    public enum ColorReserva
    {
        bgsky,
        bgorange,
        bggreen,
        bgyellow,
        bgpink,
        bgpurple,
        bglightred
    }

}
